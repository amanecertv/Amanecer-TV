<?php
/**
 * Header section.
 */
require get_template_directory().'/inc/ansar/hooks/hook-header.php';

/**
 * All Hookes
 */
require get_template_directory().'/inc/ansar/hooks/hooks.php';

/**
 * Category Meta Hookes
 */
require get_template_directory().'/inc/ansar/hooks/hook-meta.php';